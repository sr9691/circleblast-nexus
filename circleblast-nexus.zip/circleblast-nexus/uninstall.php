<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
// Intentionally no destructive cleanup by default (requires explicit approval).
